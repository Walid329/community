<?php include('include.php');?>
<style>
  .flex{
    display:flex;
    flex-direction:column;
  }
  .flexmini{
    display:flex;
    flex-direction:row;
  }
</style>
</head>
<body>
<div class='jumbotron' style='margin-bottom:0px'>
  <h2 class='display-4'>Civitas</h2>
  <p class='lead'>Here you can volunteer for anyone in your community asking for help</p>
</div>
<div class='flex'>
  <div class='flexmini'><img src='Images/volunteer1.jpg' style='width:1000px'><div class='jumbotron indexjumbo' style='margin-bottom:0px'><h3 class='display-5' style='text-align:center;margin-top:25%; margin-bottom:25%'>Create an account and enjoy the ability to volunteer at a myriad of locales</h3></div></div>
  <div class='flexmini'><div class='jumbotron indexjumbo' style='margin-bottom:0px'><h3 class='display-5' style='text-align:center;margin-top:25%;margin-bottom:25%'>Help out in your community to make it a better place!</h3></div><img src='Images/volunteer2.jpg' style='width:1000px'></div>
</div>
</body>
</html>