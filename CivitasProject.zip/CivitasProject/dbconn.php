<?php
session_start();
$pdo = new PDO('mysql:host=localhost;dbname=community',"root","root");
