DB username: root
DB password: root
Table number: 14A
Team members: Kidus Zegeye, Walid Esse
Team name: Green Circle Team
Project name: Civitas
